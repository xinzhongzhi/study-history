//
//  XWDrawerTypeListController.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/15.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import "XWBasicListController.h"

@interface XWDrawerTypeListController : XWBasicListController

@end
