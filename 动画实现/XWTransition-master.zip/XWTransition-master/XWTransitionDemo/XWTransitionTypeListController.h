//
//  ViewController.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/9.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import "XWBasicListController.h"

@interface XWTransitionTypeListController : XWBasicListController


@end

