//
//  XWMagicMoveListController.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/12.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import "XWBasicListController.h"

@interface XWMagicMoveListController : XWBasicListController

@end
