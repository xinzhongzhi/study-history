//
//  XWMagicMoveToTwoController.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/19.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XWMagicMoveFromTwoController : UIViewController

@end
