//
//  XWMagicMoveFromController.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/12.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import "XWBasicFromController.h"

NS_ASSUME_NONNULL_BEGIN

@interface XWMagicMoveFromController : XWBasicFromController

- (void)xw_setImage:(UIImage *)img;

@end

NS_ASSUME_NONNULL_END