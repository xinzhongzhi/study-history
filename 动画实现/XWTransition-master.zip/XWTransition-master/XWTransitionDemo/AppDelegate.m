//
//  AppDelegate.m
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/9.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    return YES;
}

@end
