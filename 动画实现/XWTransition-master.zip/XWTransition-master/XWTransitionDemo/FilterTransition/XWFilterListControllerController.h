//
//  XWFilterListControllerViewController.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/17.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import "XWBasicListController.h"

@interface XWFilterListControllerController : XWBasicListController

@end
