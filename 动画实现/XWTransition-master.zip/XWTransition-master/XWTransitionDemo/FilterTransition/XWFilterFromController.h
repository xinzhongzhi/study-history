//
//  XWFilterFromController.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/17.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import "XWBasicFromController.h"

@interface XWFilterFromController : XWBasicFromController
@property (nonatomic, assign) NSUInteger type;

@end
