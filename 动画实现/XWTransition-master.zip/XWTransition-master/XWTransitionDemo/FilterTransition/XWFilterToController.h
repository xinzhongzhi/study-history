//
//  XWFilterToController.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/17.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import "XWBasicToController.h"

@interface XWFilterToController : XWBasicToController
@property (nonatomic, assign) NSUInteger type;

@end
