//
//  AppDelegate.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/9.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

