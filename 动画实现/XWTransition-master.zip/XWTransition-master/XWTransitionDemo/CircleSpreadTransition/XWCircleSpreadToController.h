//
//  XWCircleSpreadToController.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/12.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import "XWBasicToController.h"

@interface XWCircleSpreadToController : XWBasicToController

@end
