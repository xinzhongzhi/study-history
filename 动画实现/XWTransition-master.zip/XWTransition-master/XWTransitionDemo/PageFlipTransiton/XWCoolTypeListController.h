//
//  XWCoolTypeListController.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/13.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import "XWBasicListController.h"

@interface XWCoolTypeListController : XWBasicListController
@end
