//
//  XWPageFlipToController.h
//  XWTransitionDemo
//
//  Created by wazrx on 16/6/13.
//  Copyright © 2016年 wazrx. All rights reserved.
//

#import "XWBasicToController.h"

@interface XWCoolToController : XWBasicToController
@property (nonatomic, assign) NSUInteger type;

@end
